let title = document.getElementById("title");
let desc = document.getElementById("desc");
let submit = document.getElementById("btn");
console.log(title,desc,submit);
let noteElem=document.querySelector(".notes")
submit.addEventListener("click",(e)=>{
    e.preventDefault(); 
    addNotes()

})
function addNotes(){
    let titleVal=title.value
    let descVal=desc.value
    
    let card=document.createElement("div");
    card.classList.add("card");
    if(titleVal){
        card.innerHTML=`
        <h3>${titleVal}</h3>
        <p>${descVal}</p>
        <button class="del">Delete</button>`
        noteElem.appendChild(card);
        
    }
    let clear=card.querySelector(".del");
    clear.addEventListener("click",()=>{
        card.remove();
        
    })  
}
