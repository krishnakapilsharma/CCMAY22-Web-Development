const questions = [
    { "q": "What is the capital of Telangana?", "a1": "Hyderabad", "a2": "Khammam", "a3": "Vizag", "a4": "Delhi" },
    { "q": "What is the capital of India?", "a1": "Hyderabad", "a2": "Khammam", "a3": "Vizag", "a4": "Delhi" },
    { "q": "Brahmaputra River when it flows out of India into Bangladesh is called as ________?", "a1": "Bangshi River", "a2": "Mahananda River", "a3": "Jamuna River", "a4": "Yamuna River" },
    { "q": "The Khadakwasla Dam is located in which state?", "a1": "Punjab", "a2": "Maharashtra", "a3": "Odisha", "a4": "Karnataka" },
    { "q": "Which among the following mountain peaks is not in Himalayan Range?", "a1": "K2", "a2": "Kanchenjunga", "a3": "Nanga parbat", "a4": "Cho Oyu" },
    { "q": "Which one among the following passes connects Lhasa with Ladakh?", "a1": "Khyber", "a2": "Burzil", "a3": "Babusar", "a4": "Lanak La" },
    { "q": "Raghopur Diyara Island is located in which of the following states of India?", "a1": "Bihar", "a2": "Odisha", "a3": "West Bengal", "a4": "Assam" },
    { "q": "What percent of the total geographical area of India is under Mangrove cover?", "a1": "0.15%", "a2": " 0.5%", "a3": "1.3%", "a4": "2.1%" },
    { "q": "Which of the following is the largest mangrove forest in the world?", "a1": "Sundarban Mangrove forest", "a2": "Bhitarkanika Mangrove forest", "a3": "Florida Mangroves", "a4": "Greater Antilles mangroves" },
    { "q": "The drainage basin of which of the following rivers covers parts of the state of Karnataka, Kerala and Tamil Nadu?", "a1": "Musi", "a2": "Godavari", "a3": "Krishna", "a4": "Kaveri" }
]

const answers = [1, 4, 3, 2, 1, 4, 1, 1, 1, 4]

let qIndex = 0
const startB = document.getElementById("start-btn")
const nextB = document.getElementById("next-btn")
const quetion = document.getElementById("question")
const a1 = document.getElementById("a1")
const a2 = document.getElementById("a2")
const a3 = document.getElementById("a3")
const a4 = document.getElementById("a4")
const res = document.getElementById("result")



var results = []

const qCont = document.getElementById("question-container")

function nextQuetion() {
    if (qIndex > 0) {
        if (a1.style.backgroundColor == 'teal')
            results.push(1)
        else if (a2.style.backgroundColor == 'teal')
            results.push(2)
        else if (a3.style.backgroundColor == 'teal')
            results.push(3)
        else if (a4.style.backgroundColor == 'teal')
            results.push(4)
        else
            results.push(0)
    }
    if (qIndex < questions.length) {
        if (clicked != null)
            clicked.style.backgroundColor = 'blueviolet'
        clicked = null
        let q = questions[qIndex]
        quetion.innerHTML = "<p style=\"color:black;font-size:1.5rem;text-align:center;font-family:Helvetica\">" + q["q"] + "</p>"
        a1.innerText = q["a1"]

        a2.innerText = q["a2"]
        a3.innerText = q["a3"]
        a4.innerText = q["a4"]
        qIndex += 1
    }
    else {
        qCont.style.display = "none"
        nextB.style.display = "none"
        startB.style.display = "inline"
        if (results.length > 0) {
            let score = 0
            for (let i = 0; i < results.length; ++i)
                score += results[i] == answers[i] ? 1 : 0

            res.innerHTML = "<p style=\"color:black;font-size:1.5rem;text-align:center;font-family:Helvetica \"> Your Score is " + score + "</p>"
            res.style.display = "contents"
        }
        results = []
    }
}

function startEvent() {
    qIndex = 0
    startB.style.display = "none"
    res.style.display = "none"
    res.innerHTML = ""
    nextB.style.display = "inline"
    qCont.style.display = "contents"
    nextQuetion()

}

var clicked = null


startB.addEventListener("click", startEvent)
nextB.addEventListener("click", nextQuetion)

a1.addEventListener("click", () => {
    if (clicked != null)
        clicked.style.backgroundColor = 'blueviolet'

    a1.style.backgroundColor = 'teal'

    clicked = a1
})

a2.addEventListener("click", () => {
    if (clicked != null)
        clicked.style.backgroundColor = 'blueviolet'

    a2.style.backgroundColor = 'teal'

    clicked = a2
})
a3.addEventListener("click", () => {
    if (clicked != null)
        clicked.style.backgroundColor = 'blueviolet'

    a3.style.backgroundColor = 'teal'

    clicked = a3
})
a4.addEventListener("click", () => {
    if (clicked != null)
        clicked.style.backgroundColor = 'blueviolet'

    a4.style.backgroundColor = 'teal'

    clicked = a4
})



